<footer class="bg-dark text-center text-white">
    <div class="container p-4 pb-0">
        <section class="mb-4">
            <a href="https://facebook.com/"><img src="https://img.icons8.com/fluency/40/000000/facebook-new.png" /></a>
            <a href="https://twitter.com/"><img src="https://img.icons8.com/fluency/40/000000/twitter.png" /></a>
            <a href="https://www.instagram.com/"><img src="https://img.icons8.com/fluency/40/000000/instagram-new.png" /></a>
            <a href="https://linkedin.in/"><img src="https://img.icons8.com/fluency/40/000000/linkedin.png" /></a>
        </section>
    </div>
    <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
        ©2022 Copyright:
        <a class="text-white" href="http://localhost/Bookshop6/welcome.php">A2ZBookshop.com</a>
    </div>
</footer>